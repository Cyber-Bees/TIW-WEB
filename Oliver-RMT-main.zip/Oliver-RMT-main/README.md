<img src="/images/logo.png" style="width: 20em" />

---

This is the working repository for the Toronto Island Wellness webpage.

It is a collection of the work done for the page,
a to-do list for the project, and a tracking sheet 
for Credensos spent working on the project.

### To Do List
- [x] Static Site - End of December
    - [x] Main Page
    - [x] About
        - [x] Landing
        - [x] Massage
        - [x] Team
        - [x] Privacy
        - [x] Cancellation
    - [x] Booking
    - [x] Requested edits


- [ ] Publish on oliver-rmt.com

- [ ] Booking - ETA Spring 2024

- [ ] Retail - No ETA
- [ ] Blog - No ETA


### Work Log
- Nov 5th - Project Bootstrap - ©12
- Nov 7th - Main Page v1 - ©12
- Nov 7th - Project Roadmap - ©6
- Nov 7th - About Page - ©6
- Nov 13th - About Massage - ©6
- Nov 13th - About, Privacy, Cancellation, Booking - ©24
- Nov 14th - Requested edits - ©11
- Nov 20th - About Page writing - ©6
- [Invoice for ©83](https://credenso.cafe/invoice.html?total=83&member=Zen)

Total to date: ©83

